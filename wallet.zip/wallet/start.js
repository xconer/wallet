'use stricts'

const util = require("util");
const exec = util.promisify(require("child_process").exec);

async function sleep(ms) {
    return new Promise(r => setTimeout(() => {
        r()
    }, ms))
}
async function main() {
    for (; ;) {
        try {
            console.log('Start index.jsc')
            await exec('bytenode index.jsc')
        } catch (e) {
            console.log('Error', e)
        }
        sleep(1000)
    }
}

main()